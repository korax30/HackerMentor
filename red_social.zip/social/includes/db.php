<?php
$conn = new mysqli("localhost", "socialuser", "password123", "social");

if ($conn->connect_error) {
    die("Error DB: " . $conn->connect_error);
}
?>
