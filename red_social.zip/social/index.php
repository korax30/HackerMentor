<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>


<?php
include 'includes/db.php';

$posts = $conn->query("
SELECT posts.*, users.username, users.profile_pic 
FROM posts 
JOIN users ON posts.user_id = users.id 
ORDER BY posts.created_at DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>PicShare</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="navbar">
    PicShare
    <a href="upload.php" style="float:right;">Publicar</a>
</div>

<div class="feed">

<?php while($post = $posts->fetch_assoc()): ?>

<div class="post">

    <!-- Usuario -->
    <div class="post-header">
        <img src="uploads/<?php echo $post['profile_pic']; ?>" class="profile-pic">
	<a href="profile.php?id=<?php echo $post['user_id']; ?>">
   	<strong>@<?php echo $post['username']; ?></strong>
	</a>
        <span class="location"><?php echo $post['location']; ?></span>
    </div>

    <!-- Imagen -->
<a href="uploads/<?php echo $post['image']; ?>" target="_blank">
    <img src="uploads/<?php echo $post['image']; ?>" class="post-img">
</a>
    <!-- Caption -->
    <div class="caption">
        <strong>@<?php echo $post['username']; ?></strong>
        <?php echo $post['caption']; ?>
    </div>

    <!-- Comentarios -->
    <div class="comments">
        <?php
        $comments = $conn->query("
        SELECT comments.*, users.username 
        FROM comments 
        JOIN users ON comments.user_id = users.id
        WHERE comments.post_id = ".$post['id']."
        ");

        while($comment = $comments->fetch_assoc()):
        ?>
            <p><strong>@<?php echo $comment['username']; ?>:</strong> <?php echo $comment['comment']; ?></p>
        <?php endwhile; ?>
    </div>

</div>

<?php endwhile; ?>

</div>

</body>
</html>
