<?php
include 'includes/db.php';

$user_id = $_GET['id'];

$user = $conn->query("SELECT * FROM users WHERE id=$user_id")->fetch_assoc();

$posts = $conn->query("SELECT * FROM posts WHERE user_id=$user_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>@<?php echo $user['username']; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="navbar">
    PicShare
</div>

<div class="profile">

    <div class="profile-header">
        <img src="uploads/<?php echo $user['profile_pic']; ?>" class="profile-big">
        <h2>@<?php echo $user['username']; ?></h2>
        <p><?php echo $user['bio']; ?></p>
    </div>

    <div class="profile-posts">
        <?php while($post = $posts->fetch_assoc()): ?>
            <img src="uploads/<?php echo $post['image']; ?>" class="grid-img">
        <?php endwhile; ?>
    </div>

</div>

</body>
</html>
