<?php
include 'includes/db.php';

$message = "";

if(isset($_POST['upload'])) {

    $filename = $_FILES['file']['name'];
    $tmp = $_FILES['file']['tmp_name'];

    // Vulnerabilidad: solo valida la extensión
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if($ext == "jpg" || $ext == "png" || $ext == "gif" || $ext == "php") {

        move_uploaded_file($tmp, "uploads/" . $filename);
	// Crear post automáticamente
	$user_id = 7; // usuario atacante (andres123 por ejemplo)

	$caption = "Nueva publicación 😎";
	$location = "Bogotá";

	$conn->query("INSERT INTO posts (user_id, image, caption, location) 
	VALUES ($user_id, '$filename', '$caption', '$location')");

        $message = "Archivo subido: " . $filename;
    } else {
        $message = "Tipo no permitido";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Photo</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="navbar">
    PicShare
</div>

<div style="width:400px;margin:50px auto;background:white;padding:20px;border:1px solid #ccc;">
    <h2>Subir foto</h2>

    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file"><br><br>
        <button type="submit" name="upload">Subir</button>
    </form>

    <p><?php echo $message; ?></p>
</div>

</body>
</html>
