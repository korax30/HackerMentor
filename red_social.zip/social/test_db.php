<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "social");

if ($conn->connect_error) {
    die("ERROR: " . $conn->connect_error);
}

echo "DB OK";
?>
